function [ acc ] = f_measure(m1,m2)
%F_MEASURE Summary of this function goes here
%   Detailed explanation goes here
%   Detailed explanation goes here
m2=imresize(m2,[size(m1,1),size(m1,2)]);
m=double(m1)+double(m2);

list1=find(m==2);
list2=find(m1==1);
list3=find(m2==1);


acc=2*numel(list1)/(numel(list2)+numel(list3));


end

