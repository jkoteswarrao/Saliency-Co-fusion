op=strcat(pwd,'/');
cd('./grabcut/GrabCut/')
run('./compile_gc.m');
cd(op);
cd('./vlf2/vlfeat-0.9.17/toolbox/')

run('./vl_compile.m');
run('./vl_setup.m');
cd(op);
cd('./mdaisy-v1.0/');
mex mex_compute_all_descriptors.cpp
mex mex_compute_descriptor.cpp
cd(op)