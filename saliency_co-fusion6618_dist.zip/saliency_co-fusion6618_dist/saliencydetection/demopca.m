clear all;
close all;

IN_DIR = '/input/';
OUT_DIR= '/output/';

%% ENTER YOUR CODE HERE

calcSaliency(IN_DIR,OUT_DIR,1);

%Hey